package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class Acceuil extends AppCompatActivity {

    private TextView tvusername;
    private Button btnajout,btnaff;
    public static ArrayList<Contact> data=new ArrayList<Contact>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_acceuil);//R hiya ressource
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //set contentView Acceuil.this c le context
        //context c l'activité courante qui occupe l'ecran
        tvusername=findViewById(R.id.txt_acc);
        btnajout=findViewById(R.id.btnajout_acc);
        btnajout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //lancer activité
                //Intent i=new Intent();
                //i.setAction(Intent.ACTION_DIAL);
                //acceuil.this c le contexte bich tlanci activité
                Intent i=new Intent(Acceuil.this,Ajout.class);
                startActivity(i);
                //finish();//min ghirha ylanci ajout fou9 acceuil
            }
        });
        btnaff=findViewById(R.id.btnaff_acc);//this.find c l'acceuil, recuperer depuis son contexte, btnaff_acc tji mil acceuil.this
        btnaff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(Acceuil.this,Affichage.class);
                startActivity(i);
            }
        });
        Intent x=this.getIntent();
        Bundle b=x.getExtras();
        String u=b.getString("User");
        tvusername.setText("Acceuil de M. "+u);

    }
}