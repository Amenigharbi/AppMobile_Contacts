package com.example.myapplication;

import static com.example.myapplication.Acceuil.data;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class Affichage extends AppCompatActivity {

    ListView lv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_affichage);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //affichage data fil liste view
        //les views composants graphiques
        //pour chaque position de data on va creer objet graphique  text view w n7otouh fil position
        //les views seront affichés fil list view
        //les composants pour creer les views nommés adapter ad , mettre dans les list view
        //list view affiché les views creer par ad
        // plusieurs types d'adapter : arrayadapter
        //tout composant android prend premier parameter context , ili mayist7a9ouch context les classes
        //adapter ye5ou context affichage.this deuxieme parameter view ili bich nchoufoha , android.R.layout.simpleListItem 1, liste des données Acceuil.data
        //parcourir les données , pour chaque données on va creer listitem ili hiya simple text view
        //fama video
        // adapter pour affichage : class MyContactAdapter doit herité de base adapter
        lv=Affichage.this.findViewById(R.id.lv);
       /* ArrayAdapter ad =new ArrayAdapter(Affichage.this,android.R.layout.simple_list_item_1,Acceuil.data);
        lv.setAdapter(ad);

        */
        ContactManager manager = new ContactManager(Affichage.this);
        manager.ouvrir();
        ArrayList<Contact> contacts = manager.getAllContact();
        manager.fermer();

        // Créer et définir l'adaptateur pour afficher les contacts
        MyContactAdapter ad = new MyContactAdapter(Affichage.this, contacts);
        lv.setAdapter(ad);



    }
}