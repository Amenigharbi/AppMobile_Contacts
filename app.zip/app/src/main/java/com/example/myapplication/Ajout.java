package com.example.myapplication;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Ajout extends AppCompatActivity {

    EditText ednom,edmdp,email;
    private Button btnaj,btnqte;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_ajout);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        ednom = findViewById(R.id.NameAj);
        edmdp=findViewById(R.id.PassAj);
        email=findViewById(R.id.EmailAj);
        btnaj=findViewById(R.id.ajt_btn);
        btnqte=findViewById(R.id.qte_ajt);
        btnqte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        btnaj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nom = ednom.getText().toString();
                String mdp = edmdp.getText().toString();
                String emai = email.getText().toString();

                // Créer une instance de ContactManager pour ajouter à la base de données
                ContactManager manager = new ContactManager(Ajout.this);
                manager.ouvrir(); // Ouvrir la base de données
                manager.ajout(nom, mdp, emai); // Ajouter le contact à la base
                manager.fermer(); // Fermer la base de données après l'insertion
            }
        });

    }
}