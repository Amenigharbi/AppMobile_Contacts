package com.example.myapplication;

public class Contact
{
   String nom,prenom,numero;

    public Contact(String prenom, String nom, String numero) {
        this.prenom = prenom;
        this.nom = nom;
        this.numero = numero;
    }

    @Override
    public String toString() {
        return "Contact{" +
                "nom='" + nom + '\'' +
                ", prenom='" + prenom + '\'' +
                ", numero='" + numero + '\'' +
                '}';
    }
}
