package com.example.myapplication;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class ContactHelper extends SQLiteOpenHelper {
    public static final String table_contact="Contact";
    public static final String col_pren="Prenom";
    public static final String col_nom="Nom";
    public static final String col_num="Numero";

    String requete = "CREATE TABLE " + table_contact + " ("
            + col_pren + " TEXT NOT NULL, "
            + col_nom + " TEXT NOT NULL, "
            + col_num + " TEXT NOT NULL)";

    public ContactHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
         sqLiteDatabase.execSQL(requete);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
             sqLiteDatabase.execSQL("drop table "+table_contact);
             onCreate(sqLiteDatabase);
    }
}
