package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class ContactManager {
    SQLiteDatabase db=null;
    Context con;
    ContactManager(Context con){
         this.con=con;
    }
    public void ouvrir(){
        ContactHelper helper=new ContactHelper(con,"mabase.db",null,2);
        db=helper.getWritableDatabase();
    }
    public long ajout(String nom,String prenom, String numero){
        long a=0;
        ContentValues values=new ContentValues();
        values.put(ContactHelper.col_nom,nom);
        values.put(ContactHelper.col_pren,prenom);
        values.put(ContactHelper.col_num,numero);

        a=db.insert(ContactHelper.table_contact,null,values);
        return a;
    }
    public ArrayList<Contact> getAllContact(){
        ArrayList<Contact> l=new ArrayList<Contact>();
        Cursor cr=db.query(ContactHelper.table_contact,
                new String []{ContactHelper.col_nom,
                ContactHelper.col_pren,
                ContactHelper.col_num},null,null,null,null,null);
        cr.moveToFirst();
        while(!cr.isAfterLast()) {
            String n = cr.getString(0);
            String p = cr.getString(1);
            String num = cr.getString(2);
            l.add(new Contact(n, p, num));
            cr.moveToNext();
        }

        return l;
    }
    public void supprimer(){

    }
    public void fermer() {
        if (db != null && db.isOpen()) {
            db.close();
        }
    }

}
