package com.example.myapplication;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class MyContactAdapter extends BaseAdapter {
    Context con;
    ArrayList<Contact> data;
    public MyContactAdapter(Context con, ArrayList<Contact> data) {
        this.con=con;
        this.data=data;
    }


    @Override
    public int getCount() {
        //retourne nombre des views à creer
        //list view mta3na
        //avoir qu'il a 3 positions
        return data.size();
    }

    @Override
    public Object getItem(int position ) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    @SuppressLint("MissingInflatedId")
    public View getView(int position, View view, ViewGroup viewGroup) {
        //parcourir getView selon getCount
        //copie fichier xml selon tableau data
        //creation view holder composant ili fih icon contact , les composants ili fi westou yitsamew viewholder
        LayoutInflater inf =LayoutInflater.from(con);
        View v=inf.inflate(R.layout.view_contact,null);
        //recuperation des holders
        TextView tvnom=v.findViewById(R.id.tvnom_contact);
        TextView pseudo=v.findViewById(R.id.tvpseudo_contact);
        TextView e=v.findViewById(R.id.tvnum_contact);


        //affectation des holders
        Contact c=data.get(position);
        tvnom.setText(c.nom);
        pseudo.setText(c.prenom);
        e.setText(c.numero);


        return v;
    }
}
